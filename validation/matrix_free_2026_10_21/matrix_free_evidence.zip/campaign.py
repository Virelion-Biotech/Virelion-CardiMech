import json,subprocess,sys,os,time
from pathlib import Path
root=Path(sys.argv[1]);repo=root/'CardiMech'; reports=[]
for level,layers in [(4,6),(5,8)]:
 name=f'shell-{level}-{layers}';print('START',name,flush=True)
 try:
  p=subprocess.run([sys.executable,'scripts/validate_matrix_free.py','--level',str(level),'--layers',str(layers),'--output',str(root/name)],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=600)
  (root/(name+'.log')).write_text(p.stdout);print('DONE',name,p.returncode,p.stdout[-6000:],flush=True);reports.append({'case':name,'returncode':p.returncode})
  if p.returncode: break
 except subprocess.TimeoutExpired as e:
  (root/(name+'.log')).write_text(str(e.stdout));reports.append({'case':name,'timeout_seconds':600});print('TIMEOUT',name,flush=True);break
(root/'campaign.json').write_text(json.dumps(reports,indent=2)); print('CAMPAIGN_DONE',flush=True)
